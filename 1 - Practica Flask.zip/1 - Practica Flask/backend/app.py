from flask import Flask, render_template, request, redirect, url_for, flash, abort
import sqlite3
import os

app = Flask(__name__, template_folder="../frontend/templates", static_folder="../frontend/static")

# ¡Importante! Necesario para flash messages
app.config['SECRET_KEY'] = 'tu-clave-secreta-cambiame'

# Configuración de base de datos
DATABASE = 'movies.db'

def get_db_connection():
    """Conecta a la base de datos SQLite"""
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_database():
    """Inicializa la base de datos y crea la tabla si no existe"""
    with get_db_connection() as conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS movies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                director TEXT NOT NULL,
                year INTEGER NOT NULL,
                genre TEXT NOT NULL,
                rating REAL NOT NULL,
                description TEXT NOT NULL,
                poster_url TEXT NOT NULL
            )
        ''')
        conn.commit()

def get_all_movies():
    """Obtiene todas las películas de la base de datos"""
    with get_db_connection() as conn:
        movies = conn.execute('SELECT * FROM movies ORDER BY id DESC').fetchall()
        return [dict(movie) for movie in movies]

def get_movie_by_id(mid: int):
    """Obtiene una película por su ID"""
    with get_db_connection() as conn:
        movie = conn.execute('SELECT * FROM movies WHERE id = ?', (mid,)).fetchone()
        return dict(movie) if movie else None

def add_movie_to_db(title, director, year, genre, rating, description, poster_url):
    """Añade una nueva película a la base de datos"""
    with get_db_connection() as conn:
        conn.execute('''
            INSERT INTO movies (title, director, year, genre, rating, description, poster_url)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (title, director, year, genre, rating, description, poster_url))
        conn.commit()

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/movies")
def movies_list():
    movies = get_all_movies()
    return render_template("movies.html", movies=movies)

@app.route("/movie/<int:mid>")
def movie_detail(mid):
    movie = get_movie_by_id(mid)
    if not movie:
        abort(404)
    return render_template("movie_detail.html", movie=movie)

@app.route('/add-movie', methods=['GET', 'POST'])
def add_movie():
    if request.method == 'POST':
        # Recoger datos del formulario
        title = request.form.get('title', '').strip()
        director = request.form.get('director', '').strip()
        year = request.form.get('year', '').strip()
        genre = request.form.get('genre', '').strip()
        rating = request.form.get('rating', '').strip()
        description = request.form.get('description', '').strip()
        poster_url = request.form.get('poster_url', '').strip()
        
        # Validar que todos los campos estén presentes
        if not all([title, director, year, genre, rating, description, poster_url]):
            flash('Por favor, completa todos los campos del formulario.', 'error')
            return redirect(url_for('add_movie'))
        
        try:
            # Convertir year y rating a tipos numéricos
            year = int(year)
            rating = float(rating)
            
            # Validar rangos
            if year < 1900 or year > 2030:
                flash('El año debe estar entre 1900 y 2030.', 'error')
                return redirect(url_for('add_movie'))
            
            if rating < 0 or rating > 10:
                flash('La calificación debe estar entre 0 y 10.', 'error')
                return redirect(url_for('add_movie'))
            
            # Añadir película a la base de datos
            add_movie_to_db(title, director, year, genre, rating, description, poster_url)
            flash('¡Película añadida correctamente!', 'success')
            return redirect(url_for('movies_list'))
            
        except ValueError:
            flash('Por favor, introduce valores válidos para el año y la calificación.', 'error')
            return redirect(url_for('add_movie'))
        except Exception as e:
            flash('Error al añadir la película a la base de datos.', 'error')
            return redirect(url_for('add_movie'))
    
    return render_template('add_movie.html')

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        message = request.form.get('message')
        
        if not name or not email or not message:
            flash('Por favor rellena los campos requeridos.', 'error')
            return redirect(url_for('contact'))
        
        flash('Gracias por tu mensaje — te responderemos pronto.', 'success')
        return redirect(url_for('contact'))
    
    return render_template('contact.html')

@app.errorhandler(404)
def page_not_found(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('500.html'), 500

if __name__ == "__main__":
    # Inicializar base de datos al arrancar la aplicación
    init_database()
    app.run(debug=True)